Modern Calculator — Android Native

هذا مشروع Android جاهز للبناء إلى APK.
لا يحتاج SDL2 ولا Qt؛ الواجهة Android Native وتعمل باللمس.

لبناء APK من الهاتف:
1. افتح المشروع في AndroidIDE.
2. انتظر مزامنة Gradle.
3. اختر Build > Assemble Debug APK.
4. ستجد APK في:
   app/build/outputs/apk/debug/app-debug.apk

يمكن أيضًا فتحه في Android Studio على الكمبيوتر.
