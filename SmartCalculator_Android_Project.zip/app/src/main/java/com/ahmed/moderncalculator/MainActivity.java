package com.ahmed.moderncalculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

public class MainActivity extends Activity {
    CalculatorView calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,15,20));
        getWindow().setNavigationBarColor(Color.BLACK);
        calc = new CalculatorView();
        setContentView(calc);
    }

    class CalculatorView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        String display = "0";
        String expression = "";
        double first = 0;
        String op = "";
        boolean waiting = true;
        boolean error = false;

        String[] keys = {
            "AC","⌫","√","÷",
            "7","8","9","×",
            "4","5","6","−",
            "1","2","3","+",
            "0",".","=","%",
            "xʸ","MOD","±","C"
        };

        RectF[] rects = new RectF[24];

        CalculatorView() {
            super(MainActivity.this);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            setBackgroundColor(Color.rgb(8,11,15));
        }

        String fmt(double x) {
            if (Double.isNaN(x) || Double.isInfinite(x)) return "Error";
            if (Math.abs(x) < 1e-12) x = 0;
            BigDecimal b = BigDecimal.valueOf(x).setScale(12, RoundingMode.HALF_UP).stripTrailingZeros();
            return b.toPlainString();
        }

        double val() {
            try { return Double.parseDouble(display); }
            catch (Exception e) { return 0; }
        }

        void clear() {
            display="0"; expression=""; first=0; op=""; waiting=true; error=false;
        }

        void err(String s) {
            display="Error"; expression=s; op=""; waiting=true; error=true;
        }

        void number(String k) {
            if (waiting || error) {
                display = k.equals(".") ? "0." : k;
                waiting=false; error=false; return;
            }
            if (k.equals(".") && display.contains(".")) return;
            if (display.length() < 18) display += k;
        }

        void back() {
            if (waiting || error) return;
            if (display.length() <= 1 || (display.length()==2 && display.charAt(0)=='-'))
                display="0";
            else display=display.substring(0,display.length()-1);
        }

        void sign() {
            if (error) return;
            double x=val();
            if (x!=0) display=fmt(-x);
        }

        void root() {
            if (error) return;
            double x=val();
            if (x<0) { err("Invalid square root"); return; }
            expression="√"+fmt(x);
            display=fmt(Math.sqrt(x));
            waiting=true;
        }

        void percent() {
            if (error) return;
            double x=val();
            display=fmt(x/100.0);
            expression=fmt(x)+"%";
            waiting=true;
        }

        void choose(String newOp) {
            if (error) return;
            if (!op.isEmpty() && !waiting) calculate();
            first=val();
            op=newOp;
            expression=fmt(first)+" "+newOp;
            waiting=true;
        }

        void calculate() {
            if (op.isEmpty() || error) return;
            double second=val(), result=0;
            switch(op) {
                case "+": result=first+second; break;
                case "-": result=first-second; break;
                case "*": result=first*second; break;
                case "/":
                    if(second==0){err("Cannot divide by zero");return;}
                    result=first/second; break;
                case "MOD":
                    if(second==0){err("Cannot use MOD with zero");return;}
                    result=first%second; break;
                case "^": result=Math.pow(first,second); break;
            }
            expression=fmt(first)+" "+op+" "+fmt(second)+" =";
            display=fmt(result);
            first=result; op=""; waiting=true;
        }

        void drawRound(Canvas c, RectF r, int color, float radius) {
            p.setColor(color);
            c.drawRoundRect(r, radius, radius, p);
        }

        void text(Canvas c, String s, float size, int color, float x, float y, Paint.Align align) {
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(size);
            p.setColor(color);
            p.setTextAlign(align);
            c.drawText(s,x,y,p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();

            text(c,"الحاسبة الذكية",19,Color.rgb(230,235,242),w/2f,34,Paint.Align.CENTER);

            RectF screen=new RectF(10,55,w-10,220);
            drawRound(c,screen,Color.rgb(21,26,34),24);

            if(!expression.isEmpty())
                text(c,expression,16,Color.rgb(110,124,143),w-30,88,Paint.Align.RIGHT);

            float resultSize = display.length()>11 ? 42 : 58;
            text(c,display,resultSize,Color.rgb(248,249,251),w-30,177,Paint.Align.RIGHT);

            float top=238, bottom=34, side=10, gap=7;
            float bw=(w-2*side-3*gap)/4f;
            float bh=(h-top-bottom-5*gap)/6f;

            for(int i=0;i<24;i++){
                int row=i/4, col=i%4;
                float x=side+col*(bw+gap);
                float y=top+row*(bh+gap);
                RectF r=new RectF(x,y,x+bw,y+bh);
                rects[i]=r;

                String k=keys[i];
                int bg=Color.rgb(27,34,44);
                int fg=Color.rgb(240,243,247);

                if(k.equals("=")){ bg=Color.rgb(55,137,250); fg=Color.WHITE; }
                else if(k.equals("+")||k.equals("−")||k.equals("×")||k.equals("÷")||k.equals("√")){
                    bg=Color.rgb(38,50,65); fg=Color.rgb(115,183,255);
                } else if(k.equals("AC")||k.equals("⌫")){
                    bg=Color.rgb(38,45,55); fg=Color.rgb(255,188,108);
                } else if(k.equals("xʸ")||k.equals("MOD")||k.equals("%")||k.equals("±")||k.equals("C")){
                    bg=Color.rgb(32,40,50); fg=Color.rgb(200,208,218);
                }

                drawRound(c,r,bg,18);
                float fs=(k.equals("MOD"))?25:34;
                text(c,k,fs,fg,r.centerX(),r.centerY()-((p.ascent()+p.descent())/2),Paint.Align.CENTER);
            }

            text(c,"حسابات سريعة • دقيقة • سهلة",14,Color.rgb(88,102,119),
                    w/2f,h-12,Paint.Align.CENTER);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;

            float x=e.getX(), y=e.getY();
            for(int i=0;i<24;i++){
                if(rects[i]!=null && rects[i].contains(x,y)){
                    press(keys[i]);
                    invalidate();
                    performClick();
                    return true;
                }
            }
            return true;
        }

        @Override public boolean performClick() {
            super.performClick(); return true;
        }

        void press(String k) {
            if((k.length()==1 && Character.isDigit(k.charAt(0))) || k.equals(".")) number(k);
            else if(k.equals("AC")||k.equals("C")) clear();
            else if(k.equals("⌫")) back();
            else if(k.equals("±")) sign();
            else if(k.equals("√")) root();
            else if(k.equals("%")) percent();
            else if(k.equals("xʸ")) choose("^");
            else if(k.equals("MOD")) choose("MOD");
            else if(k.equals("+")) choose("+");
            else if(k.equals("−")) choose("-");
            else if(k.equals("×")) choose("*");
            else if(k.equals("÷")) choose("/");
            else if(k.equals("=")) calculate();
        }
    }
}
